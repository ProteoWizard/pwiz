#!/usr/bin/env python3
"""
Generate a tiny synthetic polarity-switching MS1 mzML for MixedPolarityFullScanTest.

The file alternates scan polarity (even scans positive, odd scans negative) so that
a single small molecule with both [M+H]+ and [M-H]- precursors extracts a real MS1
chromatogram for *each* polarity from the same replicate. Selecting that molecule with
the chromatogram graph un-split puts both precursors in one pane; clicking a peak then
drives GraphFullScan.CreateSingleScan with a transition list that spans both polarities
(see ProteoWizard/pwiz issue #4240).

Provenance script, checked into the test zip (cf. the CreateMzmlFiles.bat convention).
Run: python GenerateMixedPolarityMzml.py  ->  MixedPolarity.mzML
"""
import base64
import math
import struct

# --- Molecule: neutral formula C20H30O2 (monoisotopic), two adducts -----------------
MONO = {'C': 12.0, 'H': 1.0078250319, 'O': 15.9949146221}
FORMULA = {'C': 20, 'H': 30, 'O': 2}
PROTON = 1.00727646688
NEUTRON = 1.00335

M = sum(MONO[el] * n for el, n in FORMULA.items())
MZ_POS = M + PROTON   # [M+H]+
MZ_NEG = M - PROTON   # [M-H]-

# --- Scan layout --------------------------------------------------------------------
N_SCANS = 21                 # even index -> positive, odd index -> negative
RT_STEP_MIN = 0.1            # 0.0 .. 2.0 min
APEX_INDEX = 10              # chromatographic apex (RT 1.0 min)
SIGMA_SCANS = 3.0
BASE_INTENSITY = 100000.0


def gaussian(i):
    return BASE_INTENSITY * math.exp(-((i - APEX_INDEX) ** 2) / (2.0 * SIGMA_SCANS ** 2))


def b64_doubles(values):
    raw = b''.join(struct.pack('<d', v) for v in values)
    return base64.b64encode(raw).decode('ascii')


def spectrum_xml(index):
    positive = (index % 2 == 0)
    mz0 = MZ_POS if positive else MZ_NEG
    rt = index * RT_STEP_MIN
    apex = gaussian(index)
    # monoisotopic peak + one isotope peak, so MS1 extraction sees real signal
    mzs = [mz0, mz0 + NEUTRON]
    ints = [apex, apex * 0.3]
    mz_b64 = b64_doubles(mzs)
    int_b64 = b64_doubles(ints)
    polarity = ('MS:1000130', 'positive scan') if positive else ('MS:1000129', 'negative scan')
    return f'''      <spectrum index="{index}" id="scan={index + 1}" defaultArrayLength="{len(mzs)}">
        <cvParam cvRef="MS" accession="MS:1000511" name="ms level" value="1"/>
        <cvParam cvRef="MS" accession="MS:1000579" name="MS1 spectrum" value=""/>
        <cvParam cvRef="MS" accession="MS:1000127" name="centroid spectrum" value=""/>
        <cvParam cvRef="MS" accession="{polarity[0]}" name="{polarity[1]}" value=""/>
        <scanList count="1">
          <cvParam cvRef="MS" accession="MS:1000795" name="no combination" value=""/>
          <scan>
            <cvParam cvRef="MS" accession="MS:1000016" name="scan start time" value="{rt}" unitCvRef="UO" unitAccession="UO:0000031" unitName="minute"/>
          </scan>
        </scanList>
        <binaryDataArrayList count="2">
          <binaryDataArray encodedLength="{len(mz_b64)}">
            <cvParam cvRef="MS" accession="MS:1000523" name="64-bit float" value=""/>
            <cvParam cvRef="MS" accession="MS:1000576" name="no compression" value=""/>
            <cvParam cvRef="MS" accession="MS:1000514" name="m/z array" value="" unitCvRef="MS" unitAccession="MS:1000040" unitName="m/z"/>
            <binary>{mz_b64}</binary>
          </binaryDataArray>
          <binaryDataArray encodedLength="{len(int_b64)}">
            <cvParam cvRef="MS" accession="MS:1000523" name="64-bit float" value=""/>
            <cvParam cvRef="MS" accession="MS:1000576" name="no compression" value=""/>
            <cvParam cvRef="MS" accession="MS:1000515" name="intensity array" value="" unitCvRef="MS" unitAccession="MS:1000131" unitName="number of detector counts"/>
            <binary>{int_b64}</binary>
          </binaryDataArray>
        </binaryDataArrayList>
      </spectrum>'''


def main():
    spectra = '\n'.join(spectrum_xml(i) for i in range(N_SCANS))
    doc = f'''<?xml version="1.0" encoding="utf-8"?>
<mzML xmlns="http://psi.hupo.org/ms/mzml" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://psi.hupo.org/ms/mzml http://psidev.info/files/ms/mzML/xsd/mzML1.1.0.xsd" version="1.1.0">
  <cvList count="2">
    <cv id="MS" fullName="Proteomics Standards Initiative Mass Spectrometry Ontology" version="4.1.30" URI="https://raw.githubusercontent.com/HUPO-PSI/psi-ms-CV/master/psi-ms.obo"/>
    <cv id="UO" fullName="Unit Ontology" version="releases/2020-03-10" URI="http://ontologies.berkeleybop.org/uo.obo"/>
  </cvList>
  <fileDescription>
    <fileContent>
      <cvParam cvRef="MS" accession="MS:1000579" name="MS1 spectrum" value=""/>
    </fileContent>
  </fileDescription>
  <softwareList count="1">
    <software id="pwiz" version="3.0">
      <cvParam cvRef="MS" accession="MS:1000615" name="ProteoWizard software" value=""/>
    </software>
  </softwareList>
  <instrumentConfigurationList count="1">
    <instrumentConfiguration id="IC1">
      <cvParam cvRef="MS" accession="MS:1000031" name="instrument model" value=""/>
    </instrumentConfiguration>
  </instrumentConfigurationList>
  <dataProcessingList count="1">
    <dataProcessing id="pwiz_processing">
      <processingMethod order="0" softwareRef="pwiz">
        <cvParam cvRef="MS" accession="MS:1000544" name="Conversion to mzML" value=""/>
      </processingMethod>
    </dataProcessing>
  </dataProcessingList>
  <run id="MixedPolarity" defaultInstrumentConfigurationRef="IC1">
    <spectrumList count="{N_SCANS}" defaultDataProcessingRef="pwiz_processing">
{spectra}
    </spectrumList>
  </run>
</mzML>
'''
    with open('MixedPolarity.mzML', 'w', encoding='utf-8', newline='\n') as f:
        f.write(doc)
    print(f'M (neutral monoisotopic) = {M:.6f}')
    print(f'[M+H]+ = {MZ_POS:.6f}  (positive scans)')
    print(f'[M-H]- = {MZ_NEG:.6f}  (negative scans)')
    print(f'scans = {N_SCANS} (even=positive, odd=negative), apex RT = {APEX_INDEX * RT_STEP_MIN} min')
    print('wrote MixedPolarity.mzML')


if __name__ == '__main__':
    main()
