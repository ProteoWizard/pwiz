/* SQL script to reduce size of "BSA_Protea_label_free_meth3.blib" and "BSA_Protea_label_free_meth3.redundant.blib" by removing
data that is not used by the test.
The test only looks at a few peptides whose sequence starts with either "AA" or "IK".
 */
UPDATE RefSpectra SET numPeaks = 0 WHERE peptideSeq NOT IN ('AAALADFR', 'AAGTVVFAVNRAK') AND peptideSeq NOT LIKE 'IK%';
DELETE FROM RefSpectraPeaks WHERE RefSpectraId NOT IN (SELECT id FROM RefSpectra WHERE peptideSeq IN ('AAALADFR', 'AAGTVVFAVNRAK') OR peptideModSeq = 'IKNLQSLDPSH' AND precursorCharge = 2 OR peptideModSeq = 'IKNLQS[+79.96633]LDPSH' AND precursorCharge = 3 OR peptideModSeq LIKE 'IKNLQSLDPS[+79.96633]H');
DELETE FROM RetentionTimes WHERE RefSpectraId NOT IN (SELECT id FROM RefSpectra WHERE peptideSeq IN ('AAALADFR', 'AAGTVVFAVNRAK') OR peptideSeq LIKE 'IK%');
DROP INDEX idxPeptideMod;
DROP INDEX idxPeptide;
DROP INDEX idxMoleculeName;
DROP INDEX idxInChiKey;
DROP TABLE Modifications;
VACUUM;
