
command_args <- commandArgs(trailingOnly = FALSE)
script_args <- commandArgs(trailingOnly = TRUE)
# print(command_args)

if (length(script_args) > 0) {
  reportPath <- script_args[1]
} else {
#reportPath = "J:/Webinar14/archive/Precursor Peak Areas Scored-assay-lib.csv"
#reportPath = "J:/Webinar14/archive/Precursor Peak Areas Scored-Blib.csv"
#reportPath = "J:/Webinar14/archive/AM/Precursor Peak Areas Scored-assay-lib-irt10.csv"
#reportPath = "J:/Webinar14/Precursor Peak Areas Scored-Blib-new.csv"
reportPath = "J:/Webinar14/Precursor Peak Areas Scored-Blib-new-irt10.csv"
#reportPath = "J:/Webinar14/oven/Navarro 2016 Blib-complete/Precursor Peak Areas Scored-blib.csv"
}
cat("Reading ", reportPath, "\n")
peaksTable = read.csv(reportPath, stringsAsFactors = F)
head(peaksTable)
qcols = c(6, 8, 10, 12, 14, 16)
ucols = c(2, 3, 4, 5, 6, 7)
uniqueTable = aggregate(x = peaksTable[,qcols], by = list(peaksTable$Modified.Sequence), FUN = "min")
head(uniqueTable)
cat("rows = ", nrow(peaksTable), ", unique = " , nrow(uniqueTable), "\n")
peaksTable$Min = apply(peaksTable[,qcols], 1, min)
peaksTable$Max = apply(peaksTable[,qcols], 1, max)
uniqueTable$Min = apply(uniqueTable[,ucols], 1, min)
uniqueTable$Max = apply(uniqueTable[,ucols], 1, max)
detected = length(which(peaksTable$Min < 0.01))
complete = length(which(peaksTable$Max < 0.01))
detectRuns = c()
for (col in qcols) {
  detectRuns = c(detectRuns, length(which(peaksTable[[col]] < 0.01)))
}
detectU = length(which(uniqueTable$Min < 0.01))
completeU = length(which(uniqueTable$Max < 0.01))
detectRunsU = c()
for (col in ucols) {
  detectRunsU = c(detectRunsU, length(which(uniqueTable[[col]] < 0.01)))
}

percentDetections = round(detected / nrow(peaksTable) * 100, 1)
percentRunDetections = round(mean(detectRuns) / detected * 100, 1)
percentComplete = round(complete / nrow(peaksTable) * 100, 1)
percentDetectionsU = round(detectU / nrow(uniqueTable) * 100, 1)
percentRunDetectionsU = round(mean(detectRunsU) / detectU * 100, 1)
percentCompleteU = round(completeU / nrow(uniqueTable) * 100, 1)

cat("detected = ", detected, " - ", percentDetections, "% (", paste(detectRuns, collapse = ", "), ") - ", percentRunDetections, "%; unique = ", detectU, " - ", percentDetectionsU, "% (", paste(detectRunsU, collapse = ", "), ") - ", percentRunDetectionsU, "%\n", sep = "")
cat("complete = ", complete, " - ", percentComplete, "%; unique = ", completeU, " - ", percentCompleteU, "%\n", sep = "")

# Original Bruker isolation scheme
# targetMzs = c(412.5, 437.5, 462.5, 487.5, 512.5, 537.5, 562.5, 587.5, 612.5, 637.5, 662.5, 687.5, 712.5, 737.5, 762.5, 787.5, 812.5, 837.5, 862.5, 887.5, 912.5, 937.5, 962.5, 987.5)
# titleSuffix = "Bruker Original"
# 2-cycle 50% overlapped isolation scheme
# targetMzs = c(413.4, 439.4, 465.5, 491.5, 517.5, 543.5, 569.5, 595.5, 621.5, 647.5, 673.6, 699.6, 725.6, 751.6, 777.6, 803.6, 829.6, 855.6, 881.7, 907.7, 933.7, 959.7, 985.7, 1011.7)
# titleSuffix = "Overlapped"
# deltaClosestTarget <- function(precursorMz)
# {
#   precursorMz - targetMzs[which.min(abs(precursorMz - targetMzs))]
# }
# peaksTable$PrecursorMz = as.numeric(substr(peaksTable$Precursor, 0, nchar(peaksTable$Precursor) - peaksTable$PrecursorCharge))
# peaksTable$DeltaPrecursorMz = sapply(peaksTable$PrecursorMz, deltaClosestTarget)
# detectedPeaks = peaksTable[which(peaksTable$Min < 0.01),]
# hist(peaksTable$DeltaPrecursorMz[which(peaksTable$PrecursorMz < 1000)], breaks = 52, main = paste("Targeted Precursors by Delta Precursor m/z (", titleSuffix, ")", sep = ""), xlab = "Delta Precursor m/z from Isolation Target m/z")
# hist(detectedPeaks$DeltaPrecursorMz[which(detectedPeaks$PrecursorMz < 1000)], breaks = 52, main = paste("Detected Precursors by Delta Precursor m/z (", titleSuffix, ")", sep = ""), xlab = "Delta Precursor m/z from Isolation Target m/z")
