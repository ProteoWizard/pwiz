# Cran packages
install.packages("rmarkdown", repos = "https://mran.revolutionanalytics.com/snapshot/2016-01-02")

install.packages(c("DBI", "XML", "sp", "RSQLite", "Rcpp", 
				"MatrixModels", "robustbase", "lme4", "MALDIquant", "colorspace",
				"data.table", "uuid", "readr", "aplpack",
				"gplots", "missForest", "outliers", "ROCR", "tidyr",
				"VIM", "vioplot", "xtable", "psych", "digest"))

install.packages("BiocManager")
BiocManager::install(c("MSnbase", "Biobase", "limma", "marray", "S4Vectors", 
                       "IRanges", "vsn", "mzR", "mzID", "affy", 
                       "pcaMethods", "MSstats"))	

install.packages("devtools")
library(devtools)

# WARNING: Rtools is required to build R packages, but is not currently installed.
# Please download and install Rtools 3.5 from https://cran.r-project.org/bin/windows/Rtools/history.html and then run find_rtools().
find_rtools()

Sys.setenv(R_REMOTES_NO_ERRORS_FROM_WARNINGS="true" )
install_github("IFIproteomics/LFQbench")
