# Necessary libraries
suppressPackageStartupMessages(library(LFQbench))

# Parse the variables out of the command line, if called from command line
command_args <- commandArgs(trailingOnly = FALSE)
script_args <- commandArgs(trailingOnly = TRUE)
# print(command_args)
file.arg.name <- "--file="

if (length(script_args) > 0 && length(grep(file.arg.name, command_args)) > 0) {
  report_file <- script_args[1]
  report_dir <- dirname(report_file)
  if (report_dir != "") {
    report_dir <- paste(report_dir, "/", sep = "")
  }
  working_dir <- dirname(report_file)
} else {
  errorCondition("This R script requiers the path to a csv file as the first argument. Please supply a csv file.")
}

# Human, Yeast, E. coli composition
sampleComposition = data.frame( species = c("HUMAN", "YEAST", "ECOLI"), 
                                A = c( 65, 30, 05 ), 
                                B = c( 65, 15, 20 ) )


# Data sets being processed - can specify more in this structure in the future
dataSets = data.frame( "HYE124_TTOF6600_64var" = c( "lgillet_I150211_008", "lgillet_I150211_010", "lgillet_I150211_012", # A 
                                                    "lgillet_I150211_009", "lgillet_I150211_011", "lgillet_I150211_013" # B
                                                    ),
                       row.names = c( "A1", "A2", "A3", "B1", "B2", "B3" ) )

# Species tags from the FASTA sequence names                       
speciesTags = list( HUMAN = "_HUMAN", YEAST = "_YEAS", ECOLI = "_ECOLI" )

# Init configurations
LFQbench.initConfiguration( SampleComposition = sampleComposition )
FSWE.initConfiguration( injectionNames = dataSets, speciesTags = speciesTags )
LFQbench.setDataRootFolder( rootFolder = working_dir, createSubfolders = T )

# Generate reports and plots
FSWE.generateReports("SWATHbenchmark.csv",
              softwareSource = "Skyline",
              keep_original_names = T,
              singleHits = F,
              plotHistogram = T,
              plotHistNAs = T,
              reportSequences = F)
nye123.res = LFQbench.batchProcessRootFolder()
