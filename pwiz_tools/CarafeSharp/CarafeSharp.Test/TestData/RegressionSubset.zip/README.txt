CarafeSharp regression subset (built by ai/scripts/CarafeSharp/SubsetData/build_regression_subset.py)

stellar/Ste-2024-12-02_HeLa_4mz_sDIA_400-900_21.training.parquet
  1831 of the 27424 rows of carafesharp-export-v2/stellar/Ste-2024-12-02_HeLa_4mz_sDIA_400-900_21.training.parquet (1672 peptide forms): every row of the forms whose 64-bit FNV-1a hash of
  modified_sequence, shifted right 32 bits, is 0 modulo 15. All columns and the footer are kept;
  osprey.training_export.rows and the mp_cosine_parity counts are the kept rows.
  Source SHA-256: 13730b17bca44a256efdd6b08afeffdb5a61ced6692dcbaf8087a6aec46ccd6a

library_subset_pairing.tsv, library_subset_peptides.fasta
  The 438 pair groups of carafesharp-testfiles-v1/stellar/carafe-osprey-entrapment/osprey_library_db_pairing.tsv whose peptide_pair_index is 0 modulo 500 (1752 rows), and the 1752
  records of carafesharp-testfiles-v1/stellar/carafe-osprey-entrapment/osprey_library_db_peptides.fasta holding their sequences.
