CarafeSharp test data: LibraryParitySubset, a subset of carafesharp-testfiles-v1
(built by ai/scripts/CarafeSharp/SubsetData/build_library_parity_subset.py)

Laid out as the full package, with the files LibraryParityTest and CarafeParityTest read for
a fraction of the FASTA records of each run below. Records are grouped so that no peptide,
ProteinID or decoy pair crosses groups, and every file keeps exactly what the kept records
yield (k_ms2_df fragment indexes renumbered). parameter.txt files are Carafe's, unchanged.
The fine-tuned run has no models; the second Stellar run is left out.

stellar/carafe-osprey-entrapment/osprey_initial_library
  Stellar pretrained, stellar/carafe-osprey-entrapment/osprey_train_db_peptides.fasta: the record groups whose ordinal is 0 modulo 500 (438 of 218918 groups, 876 of 437842 records);
  1016 of 494264 peptide_forms rows, 1016 TSV precursors (16790 lines).

stellar/carafe-osprey-entrapment/osprey_new_library
  Stellar fine-tuned, stellar/carafe-osprey-entrapment/osprey_library_db_peptides.fasta: the record groups whose ordinal is 0 modulo 1000 (219 of 218860 groups, 876 of 875484 records);
  990 of 988740 peptide_forms rows, 990 TSV precursors (18414 lines).

library-references/m3/ref/nocut-every50
  m3 NoCut every-50, library-references/m3/fixtures/peptides_every50.fasta: the record groups whose ordinal is 0 modulo 25 (351 of 8757 groups, 702 of 17514 records);
  980 of 24684 peptide_forms rows, 980 TSV precursors (16016 lines), 980 .blib spectra.

library-references/m3/ref/trypsin-proteins
  m3 trypsin proteins, library-references/m3/fixtures/proteins300.fasta: the record groups whose ordinal is 0 modulo 8 (37 of 295 groups, 41 of 320 records);
  1023 of 8973 peptide_forms rows, 1023 TSV precursors (17099 lines), 1023 .blib spectra.

library-references/carafe_main_varmod
  variable modifications, library-references/hela-300.fasta: the record groups whose ordinal is 0 modulo 30 (10 of 297 groups, 10 of 300 records);
  993 of 51015 peptide_forms rows, 993 TSV precursors (15486 lines), 993 .blib spectra.

stellar/carafe-osprey-entrapment/osprey_train_db_pairing.tsv
  The -pairing_manifest of nocut-every50: the 351 pair groups (702 rows) holding its kept sequences,
  or a sequence of such a group.
