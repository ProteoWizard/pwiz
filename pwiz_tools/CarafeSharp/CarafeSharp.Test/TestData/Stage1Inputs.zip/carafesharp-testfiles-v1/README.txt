CarafeSharp stage-1 inputs subset of carafesharp-testfiles-v1 (built by ai/scripts/CarafeSharp/SubsetData/build_stage1_inputs.py)

The inputs of the stage-1 entrapment FASTA builds, without their outputs: each folder that had
outputs has an expected.sha256 with the SHA-256 the full package records for them.

Inputs, unchanged: stage1/fixtures/mouse-subset1500.fasta, stellar/hela-filtered.fasta
Carafe GUI signatures: stellar/carafe-osprey-entrapment/osprey_library_db_peptides.fasta.carafe.sig, stellar/carafe-osprey-entrapment/osprey_train_db_peptides.fasta.carafe.sig, stellar/carafe-osprey/osprey_train_db_peptides.fasta.carafe.sig
Builds kept (10): foreign-mouse-sub, foreign-mouse-sub-nogate, gated-lib, gated-lib-clip-p, gated-lib-r05, gated-lib-seed7-mz, gated-train, nogate-lib, nogate-lib-r05, nogate-train
Builds left out, download-only (2): foreign-mouse (reads stage1/uniprot_mouse_dec2024_yeastENO1.fasta), foreign-mouse-r025 (reads stage1/uniprot_mouse_dec2024_yeastENO1.fasta)
