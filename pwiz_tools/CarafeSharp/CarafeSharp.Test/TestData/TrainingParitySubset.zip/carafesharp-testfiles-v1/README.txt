CarafeSharp training parity subset of carafesharp-testfiles-v1 (built by ai/scripts/CarafeSharp/SubsetData/build_training_parity_subset.py)

For TestFineTuneMatchesCarafeSubset and TestMaskingAgreesWithCarafeSubset. Only stellar/carafe-osprey-entrapment/osprey_new_library is kept.
psm_pdv.txt, meta.json, parameter.txt, model_evaluation_metrics.json, rt_test.tsv and
test_true_intensity.tsv are verbatim; the training tables keep every row (14806 spectra, 166149 fragment
rows, 19881 RT rows) so Carafe's train/test split is unchanged, but:
  fragment_intensity_df.tsv  intensities only of the 904 held-out spectra, 0.0 elsewhere
  fragment_intensity_valid.tsv  masking counts of the held-out spectra and of the 754 spectra
    whose sequence is sampled (FNV-1a key modulo 20), 0 elsewhere
  rt_train_data.tsv  rt_norm of the 999 rows of the 999 held-out forms, 0.0 elsewhere; rt, y 0.0
  ../osprey_library_db_peptides.fasta  empty; parameter.txt names it, nothing reads it
Do not fine-tune on it: the non-held-out spectra have no intensities.
