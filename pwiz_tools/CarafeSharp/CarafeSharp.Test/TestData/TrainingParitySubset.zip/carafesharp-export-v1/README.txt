CarafeSharp training parity subset of carafesharp-export-v1 (built by ai/scripts/CarafeSharp/SubsetData/build_training_parity_subset.py)

stellar/Ste-2024-12-02_HeLa_4mz_sDIA_400-900_21.training.parquet
  1132 of the 22761 rows: those whose 64-bit FNV-1a hash of sequence, shifted right 32 bits, is 0
  modulo 20, without the columns xic_rts, xic_intensities. The footer is kept; osprey.training_export.rows and the
  mp_cosine_parity counts are the kept rows, carafesharp.subset.sequence_modulus is 20.
  Source SHA-256: 8e69a2aab58e4568c700d3604539714db9f82c845266944dda1399ad459a6ea8
