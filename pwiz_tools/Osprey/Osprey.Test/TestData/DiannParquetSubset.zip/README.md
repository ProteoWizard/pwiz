# DIA-NN 2.7 library .parquet fixtures (DiannParquetSubset.zip)

Produced by DIA-NN 2.7.0 Academia (compiled Sep 15 2026) on MACS2, 2026-11-03; measured and
described in full in the fixture README at
`M:\home\brendanx\data\MacCoss\Osprey\DIA-NN\README.md` (the files here are byte copies).

| file here | source in that folder | what it is |
|---|---|---|
| `lib.parquet` | `predicted-20prot/lib.parquet` | 20-protein predicted library, `--unimod4`, 2,637 precursors, 31,497 rows, row groups (31,497, 0) |
| `lib.tsv` | `converted/lib.tsv` | `diann_library_swap.py convert lib.parquet - lib.tsv` (pyarrow float32 -> text) |
| `lib-varmods.parquet` | `predicted-20prot/varmods/lib-varmods.parquet` | same digest + variable Ox(M) (UniMod:35) and N-terminal acetyl (UniMod:1), 3,342 precursors, 39,943 rows |
| `lib-varmods.tsv` | `converted/lib-varmods.tsv` | the same conversion of `lib-varmods.parquet` |
| `report-lib-empty.parquet` | `empirical-20prot/tiny20-stellar-zero-ids/report-lib.parquet` | a search with 0 IDs: full schema (with `Trace`), 0 rows, 1 row group |

Commands (from the fixture README):

```
diann.exe --fasta tiny.fasta --fasta-search --predictor --gen-spec-lib --out-lib lib.tsv --threads 4 --cut K*,R* --missed-cleavages 1 --min-pr-charge 2 --max-pr-charge 3 --min-pr-mz 400 --max-pr-mz 900 --unimod4 --verbose 1
diann.exe --lib lib.predicted.speclib --gen-spec-lib --out-lib lib.parquet --threads 4 --verbose 1
```

The varmods library adds `--var-mods 1 --var-mod UniMod:35,15.994915,M --var-mod UniMod:1,42.010565,*n`.
