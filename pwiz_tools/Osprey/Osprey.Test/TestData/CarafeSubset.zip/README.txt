Carafe-built library test data for Osprey.Test (CarafeBlibLibraryTest)

A spectral library CarafeSharp built, with its DecoyPairs table, and the pairing manifest it was
built from, so a test can prove that Osprey reads a Carafe library's whole decoy and entrapment
design from the .blib alone - no manifest on the command line. BLIB is the communication format
between Carafe and Osprey; this is the handoff in miniature.

Files
  carafe_spectral_library.blib
      The library CarafeSharp.Test's in-process subset regression (RegressionTest, leg
      "isolated", CPU) builds from CarafeSharp.Test/TestData/RegressionSubset.zip: the fine-tune
      on the subset's training parquet, then prediction for the subset's FASTA with decoys.
      1896 precursors (948 targets, 948 decoys; 948 of them entrapment) in 347 pairing groups,
      and a DecoyPairs row for every one (RefSpectraID, IsDecoy, IsEntrapment, PairingID,
      TargetRefSpectraID, Method). Copied from the run folder
      CarafeSharp/TestResults/regression/stellarsubset-isolated-cpu-20261017-142726/out,
      built at pwiz 29c194f35c on 2026-10-17 (LibMetadata osprey.validity records the inputs).
  library_subset_pairing.tsv
      The FDRBench pairing manifest the subset was built from, copied unchanged from
      RegressionSubset.zip: 438 pair groups, 1752 rows (target, p_target, decoy, p_decoy), with
      peptide_pair_index as the pairing id. The oracle: a library entry's PairingId must be this
      file's index for its sequence, and the entrapment pairing Osprey reads from the entries
      must be this file's. Peptides of the manifest that CarafeSharp did not predict (length and
      charge filters) are simply absent from the library.

Regenerate by running CarafeSharp.Test's RegressionTest (Build-CarafeSharp.ps1 -RunTests in
the pwiz-ai scripts) and copying out/carafe_spectral_library.blib from its newest
TestResults/regression/stellarsubset-isolated-cpu-* folder; the manifest comes from
RegressionSubset.zip as it is.
