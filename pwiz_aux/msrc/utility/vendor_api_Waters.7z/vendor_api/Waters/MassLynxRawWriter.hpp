//-----------------------------------------------------------------------------------------------------
// FILE:			MassLynxRawWriter.h
// DATE:			July 2018
// COPYRIGHT(C):	Waters Corporation
//
//-----------------------------------------------------------------------------------------------------
#pragma once

#include "MassLynxRawBase.hpp"
#include "MassLynxParameters.hpp"

namespace Waters
{
namespace Lib
{
namespace MassLynxRaw
{
	using std::string;

	class MassLynxParameters;

	class MassLynxRawWriter
	{
		/**
		* Allows access to raw data information and scan statistics
		*
		* If an error is encountered then an exception will be throw, see exception codes and messages.
		*/

	public:
		/**
		* Reads the masses and intensities for the requested function and scan <br>
		* Returns an error if the raw folder already exists
		*
		* @param  strTargetPath fully qualified path
		*
		*/
		MassLynxRawWriter(const string& strTargetPath) : m_pRawWriter(NULL)
		{
			m_pCodeHandler = new MassLynxCodeHandler();
			CheckReturnCode(createRawWriter(&m_pRawWriter, strTargetPath.c_str()));
		}

		virtual ~MassLynxRawWriter()
		{
			destroyRawWriter(m_pRawWriter);
			delete m_pCodeHandler;
		}

		/**
		* Appends new function to raw data custer <br>
		* Any currently open function will be closed
		*
		* @param functionDefinition key value pairs
		*
		*/

		bool AppendFunction(const MassLynxParameters& functionDefinition)
		{
			return CheckReturnCode(appendRawFunction(m_pRawWriter, functionDefinition.GetParameters()));
		}

		/**
		* Appends new function with scan stats to raw data custer <br>
		* Any currently open function will be closed
		*
		* @param functionDefinition key value pairs
		* @param stats vector of MassLynxScanItem which are defined for each scan
		*
		*/

		bool AppendFunction(const MassLynxParameters& functionDefinition, const vector<MassLynxScanItem>& stats)
		{
			return CheckReturnCode(appendRawFunctionWithStats(m_pRawWriter, functionDefinition.GetParameters(), stats.data(), static_cast<int>(stats.size())));
		}

		/**
		* Appends a scan to the currently open function <br>
		* Scans should be appended in ascending retention time
		*
		* @param masses vector of float values to be added
		* @param intensities vector of float values to be added
		* @param fRT Scan retention time
		*
		*/
		bool AppendScan(const vector<float> & masses, const vector<float> & intensities, const float& fRT)
		{
			return CheckReturnCode(appendRawScan(m_pRawWriter, masses.data(), intensities.data(), static_cast<int>(masses.size()), fRT));
		}

		/**
		* Appends a scan with associated statistics to the currently open function
		* Scan stats must correspond to the appended function
		* Scans should be appended in ascending retention time
		*
		* @param masses vector of float values to be added
		* @param intensities vector of float values to be added
		* @param stats key value pairs of stats
		* @param fRT Scan retention time
		*
		*/
		bool AppendScan(vector<float> & masses, vector<float> & intensities, const MassLynxParameters& stats, const float& fRT)
		{
			return CheckReturnCode(appendRawScanWithStats(m_pRawWriter, masses.data(), intensities.data(), static_cast<int>(masses.size()), fRT, stats.GetParameters()));
		}

		/**
		* Sets the header item in the raw cluster
		*
		* @param headerItems key value pair header items
		*
		*/
		bool SetHeader(const MassLynxParameters& headerItems)
		{
			return CheckReturnCode(setRawHeaderItems(m_pRawWriter, headerItems.GetParameters()));
		}

		/**
		* Returns the last error message
		*/
		string GetLastMessage() const
		{
			return m_pCodeHandler->GetLastMessage();
		}

		/**
		* Returns the last error code
		*/
		int GetLastCode() const
		{
			return m_pCodeHandler->GetLastCode();
		}

		/**
		* Closes the raw data cluster
		*/
		bool Close()
		{
			return CheckReturnCode(closeRawWriter(m_pRawWriter));
		}

	protected:
		bool CheckReturnCode(const int& nCode) const
		{
			return m_pCodeHandler->CheckReturnCode(nCode, false);
		}

		CMassLynxRawWriter const GetRawWriter() const { return m_pRawWriter; }


	private:
		CMassLynxRawWriter m_pRawWriter;
		MassLynxCodeHandler* m_pCodeHandler;
	};

	namespace Extended
	{
		class MassLynxRawWriter : public Waters::Lib::MassLynxRaw::MassLynxRawWriter
		{
		public:
			MassLynxRawWriter(const string& strTargetPath) : Waters::Lib::MassLynxRaw::MassLynxRawWriter(strTargetPath) {}

			//bool AppendScan(vector<unsigned int>& masses, vector<unsigned int>& intensities, vector<unsigned int>& scans, const float& fRT)
			//{
			//	return CheckReturnCode(appendCDTScanIndex(GetRawWriter(), masses.data(), intensities.data(), static_cast<int>(masses.size()), scans.data(), static_cast<int>(scans.size()), fRT));
			//}


			bool AppendScan(const vector<float>& masses, const vector<float>& intensity, const vector<unsigned int>& scans, const float& fRT)
			{
				return CheckReturnCode(appendCDTScan(GetRawWriter(), masses.data(), intensity.data(), static_cast<int>(masses.size()), scans.data(), static_cast<int>(scans.size()), fRT));
			}
		};
	}
}
}
}