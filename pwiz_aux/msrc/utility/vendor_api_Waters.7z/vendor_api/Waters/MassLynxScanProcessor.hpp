//-----------------------------------------------------------------------------------------------------
// FILE:			MassLynxScanProcessor.h
// DATE:			July 2018
// COPYRIGHT(C):	Waters Corporation
//
//-----------------------------------------------------------------------------------------------------
#pragma once

#include "MassLynxRawBase.hpp"
#include "MassLynxParameters.hpp"

namespace Waters
{
namespace Lib
{
namespace MassLynxRaw
{
	using std::string;
	using std::vector;

	class MassLynxScanProcessor : public MassLynxBaseProcessor
	{
	public:
		MassLynxScanProcessor() : MassLynxBaseProcessor(MassLynxBaseType::SCAN) {}

	public:

		MassLynxScanProcessor& Combine(const int& nWhichFunction, const int* pScans, const int& nScans)
		{
			CheckReturnCode(combineScan(GetProcessor(), nWhichFunction, pScans, nScans));
			return *this;
		}

		// load single scan
		MassLynxScanProcessor& Load(const int& nWhichFunction, const int& nWhichScan)
		{
			CheckReturnCode(combineScan(GetProcessor(), nWhichFunction, &nWhichScan, 1));
			return *this;
		}

		// return the processed scan
		void MassLynxScanProcessor::GetScan(vector<float>& masses, vector<float>& intensities) const
		{
			// get the data..
			float* pMasses(NULL);
			float* pIntensities(NULL);
			int nSize(0);
			CheckReturnCode(getScan(GetProcessor(), &pMasses, &pIntensities, &nSize));

			// fill the vector and deallocate the memory
			ToVector(pMasses, nSize, masses);
			ToVector(pIntensities, nSize, intensities);
		}

		MassLynxScanProcessor& MassLynxScanProcessor::SetThresholdParameters(const MassLynxParameters& thresholdParameters)
		{
			CheckReturnCode(setThresholdParameter(GetProcessor(), thresholdParameters.GetParameters()));
			return *this;
		}

		MassLynxScanProcessor& MassLynxScanProcessor::Threshold(const MassLynxParameters& thresholdParameters)
		{
			SetThresholdParameters(thresholdParameters);
			return Threshold();
		}

		MassLynxScanProcessor& MassLynxScanProcessor::Threshold()
		{
			CheckReturnCode(thresholdScan(GetProcessor()));
			return *this;
		}

		MassLynxScanProcessor& SetSmoothParameters(const MassLynxParameters& smoothParameters)
		{
			CheckReturnCode(setSmoothParameter(GetProcessor(), smoothParameters.GetParameters()));
			return *this;
		}

		MassLynxParameters GetSmoothParameters()
		{
			MassLynxParameters parameters;
			CheckReturnCode(getSmoothParameter(GetProcessor(), parameters.GetParameters()));
			return parameters;
		}

		MassLynxScanProcessor& Smooth(const MassLynxParameters& smoothParameters)
		{
			SetSmoothParameters(smoothParameters);
			return Smooth();
		}

		MassLynxScanProcessor& Smooth()
		{
			CheckReturnCode(smoothScan(GetProcessor()));
			return *this;
		}


		MassLynxParameters GetCentroidParameters()
		{
			MassLynxParameters parameters;
			CheckReturnCode(getCentroidParameter(GetProcessor(), parameters.GetParameters()));
			return parameters;
		}

		MassLynxScanProcessor& Centroid()
		{
			CheckReturnCode(centroidScan(GetProcessor()));
			return *this;
		}
	};

	namespace Extended
	{
		class MassLynxScanProcessor : public Waters::Lib::MassLynxRaw::MassLynxScanProcessor
		{
		public:
			MassLynxScanProcessor() : Waters::Lib::MassLynxRaw::MassLynxScanProcessor() {}

			MassLynxScanProcessor& SetScan(const vector<float>& masses, const vector<float>& intensities)
			{
				CheckReturnCode(setScan(GetProcessor(), masses.data(), intensities.data(), static_cast<int>(masses.size()), static_cast<int>(intensities.size())));
				return *this;
			}

			MassLynxScanProcessor& SetCentroidParameters(const MassLynxParameters& centroidParameters)
			{
				CheckReturnCode(setCentroidParameter(GetProcessor(), centroidParameters.GetParameters()));
				return *this;
			}

			MassLynxScanProcessor& Centroid(const MassLynxParameters& centroidParameters)
			{
			    SetCentroidParameters(centroidParameters);
				return Centroid();
			}

			MassLynxScanProcessor& Centroid()
			{
				Waters::Lib::MassLynxRaw::MassLynxScanProcessor::Centroid();
				return *this;
			}
		};
	}
}   // MassLynxRaw
}   // Lib
}   // Waters



