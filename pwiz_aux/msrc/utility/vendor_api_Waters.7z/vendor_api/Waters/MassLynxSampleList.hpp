//-----------------------------------------------------------------------------------------------------
// FILE:			MassLynxParameters.hpp
// DATE:			Nov 2018
// COPYRIGHT(C):	Waters Corporation
//	
//-----------------------------------------------------------------------------------------------------
#pragma once

#include "MassLynxRawDefs.h"
#include "MassLynxParameters.hpp"
#include "MassLynxRawBase.hpp"

namespace Waters
{
namespace Lib
{
namespace MassLynxRaw
{
	using std::string;

	class MassLynxParameters;

	/**
	*  @brief Helper class to build sample list settings
	*/
	class MassLynxSampleList
	{
	public:
		MassLynxSampleList() : m_pSampleList(NULL)
		{
			m_pCodeHandler = new MassLynxCodeHandler();
			m_pStringHandler = new MassLynxStringHandler();
			createSampleList(&m_pSampleList);
		}

		~MassLynxSampleList()
		{
			delete m_pCodeHandler;
			delete m_pStringHandler;
			destroySampleList(m_pSampleList);
		}

		/**
		* Appends new row to the sample list <br>
		*
		* @param row key value pairs of MassLynxSampleList Items
		*
		*/
		bool AddRow(const MassLynxParameters& row)
		{
			return CheckReturnCode(addSampleListRow(m_pSampleList, row.GetParameters()));
		}

		/**
		*  Returns the sample list table in tab delimited format
		*
		*   @return string
		*/
		string ToString() const
		{
			char* chTable(NULL);
			CheckReturnCode(sampleListToString(m_pSampleList, &chTable));
			return m_pStringHandler->ToString(chTable, false);
		}

		string GetLastMessage() const
		{
			return m_pCodeHandler->GetLastMessage();
		}

		int GetLastCode() const
		{
			return m_pCodeHandler->GetLastCode();
		}

	private:
		bool CheckReturnCode(const int& nCode) const
		{
			return m_pCodeHandler->CheckReturnCode(nCode, false);
		}

	private:
		CMassLynxSampleList m_pSampleList;
		MassLynxCodeHandler* m_pCodeHandler;
		MassLynxStringHandler* m_pStringHandler;
	};

}   // MassLynxRaw
}   // Lib
}   // Waters